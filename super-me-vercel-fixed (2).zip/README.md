# Super Me — Vercel build

Questa versione è pronta per Vercel e collega davvero:
- testo → OpenAI → dati strutturati
- foto del pasto → OpenAI Vision → alimenti + kcal + proteine + carboidrati + grassi
- voce → registrazione browser → OpenAI transcription → OpenAI parser
- dati e obiettivi → localStorage del dispositivo

## Deploy su Vercel senza installare nulla

1. Apri Vercel.
2. Crea un nuovo progetto importando questa cartella tramite un repository Git, oppure carica il progetto con il metodo disponibile nel tuo account.
3. In Vercel apri:
   Settings → Environment Variables
4. Crea:
   Name: OPENAI_API_KEY
   Value: la tua NUOVA chiave OpenAI
5. Abilitala almeno per Production (consigliato anche Preview).
6. Salva.
7. Esegui un nuovo Deploy/Redeploy.

IMPORTANTE: se aggiungi o cambi la variabile dopo un deploy, devi fare Redeploy perché la nuova variabile venga applicata.

## API

/api/parse
- testo naturale
- immagini base64 compresse lato browser
- modello: gpt-5-mini

/api/transcribe
- audio registrato dal browser
- modello: gpt-4o-mini-transcribe

La OPENAI_API_KEY viene letta esclusivamente lato server tramite:
process.env.OPENAI_API_KEY

Non inserirla in app.js, index.html, localStorage o manifest.json.

## Dati personali

Questa V1 è local-first: pasti, sport, pressione e obiettivi vengono salvati nel browser del dispositivo.
Non è ancora presente un backup cloud o un account.

## Pressione

Super Me registra e visualizza misurazioni ma non formula diagnosi e non sostituisce il medico.


## Fix vocale 1.1
Corretto il parsing dei Data URL audio che includono parametri MIME come:
`audio/webm;codecs=opus`.
Il precedente decoder li rifiutava prima della chiamata a OpenAI.
Aggiunto logging diagnostico lato Vercel.
